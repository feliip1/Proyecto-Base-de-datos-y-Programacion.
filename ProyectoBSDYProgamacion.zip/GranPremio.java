package rapidoseinformaticos;


public class GranPremio {

    private String nombre;
    private String fecha;

    private Circuito circuito;
    private Temporada temporada;

    public GranPremio(String nombre, String fecha,Circuito circuito, Temporada temporada) {

        this.nombre = nombre;
        this.fecha = fecha;
        this.circuito = circuito;
        this.temporada = temporada;
    }

    public void iniciar() {
        System.out.println("Iniciando el Gran Premio de " + nombre);
    }

    public String getNombre() {
        return nombre;
    }

    public String getFecha() {
        return fecha;
    }

    public Circuito getCircuito() {
        return circuito;
    }

    public Temporada getTemporada() {
        return temporada;
    }
}