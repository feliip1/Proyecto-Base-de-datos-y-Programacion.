package rapidoseinformaticos;

import java.util.ArrayList;
import java.util.List;

public class Escuderia {

    private String nombre;
    private String pais;

    private List<Piloto> pilotos;
    private List<Coche> coches;

    public Escuderia(String nombre, String pais) {
        this.nombre = nombre;
        this.pais = pais;
        this.pilotos = new ArrayList<>();
        this.coches = new ArrayList<>();
    }

    public void inscribir() {
        System.out.println("El equipo " + nombre + " ha sido inscrito.");
    }

    public void agregarPiloto(Piloto piloto) {
        pilotos.add(piloto);
    }

    public void agregarCoche(Coche coche) {
        coches.add(coche);
    }

    public String getNombre() {
        return nombre;
    }

    public String getPais() {
        return pais;
    }

    public List<Piloto> getPilotos() {
        return pilotos;
    }

    public List<Coche> getCoches() {
        return coches;
    }
}