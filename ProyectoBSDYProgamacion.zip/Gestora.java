package rapidoseinformaticos;

import java.util.ArrayList;

public class Gestora {
  
	private ArrayList<Coche> listaCoches= new ArrayList<>();
	private ArrayList<Carrera> listaCarreras= new ArrayList<>();
	private ArrayList<GranPremio> listaGPs= new ArrayList<>();
	private ArrayList<Piloto> listaPilotos= new ArrayList<>();
	private ArrayList<Resultado> listaResultados= new ArrayList<>();
	private ArrayList<Temporada> listaTemporadas= new ArrayList<>();

	public void agregarCoche(Coche co) {
        this.listaCoches.add(co);
        System.out.println("Coche agregado con exito");
	}
	public void agregarCarrera(Carrera ca) {
		this.listaCarreras.add(ca);
        System.out.println("Carrera agregado con exito");
	}
	public void agregarGP(GranPremio gp) {
		this.listaGPs.add(gp);
        System.out.println("GranPremio agregado con exito");
	}
	public void agregarPiloto(Piloto pi) {
		this.listaPilotos.add(pi);
        System.out.println("Piloto agregado con exito");
	}
	public void agregarResultado(Resultado re) {
		this.listaResultados.add(re);
        System.out.println("Resultado agregado con exito");
	}
	public void agregarTemporada(Temporada te) {
		this.listaTemporadas.add(te);
        System.out.println("Temporada agregado con exito");
}
}
