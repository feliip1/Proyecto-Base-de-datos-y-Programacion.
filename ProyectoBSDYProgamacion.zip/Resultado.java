package rapidoseinformaticos;

public class Resultado {

    private int posicion;
    private double puntos;
    private int tiempo;
    private boolean abandono;

    private Piloto piloto;

    public Resultado(int posicion, double puntos, int tiempo,
                     boolean abandono, Piloto piloto) {

        this.posicion = posicion;
        this.puntos = puntos;
        this.tiempo = tiempo;
        this.abandono = abandono;
        this.piloto = piloto;
    }

    public int getPosicion() {
        return posicion;
    }

    public double getPuntos() {
        return puntos;
    }

    public int getTiempo() {
        return tiempo;
    }

    public boolean isAbandono() {
        return abandono;
    }

    public Piloto getPiloto() {
        return piloto;
    }
}