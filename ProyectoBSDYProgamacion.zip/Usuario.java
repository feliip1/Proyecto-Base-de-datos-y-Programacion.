package rapidoseinformaticos;

public class Usuario {

    private String nombreUsuario;
    private String correo;

    public Usuario(String nombreUsuario, String correo) {
        this.nombreUsuario = nombreUsuario;
        this.correo = correo;
    }

    public void iniciarSesion() {
        System.out.println("El usuario " + nombreUsuario + " inició sesión.");
    }

    public void cerrarSesion() {
        System.out.println("El usuario " + nombreUsuario + " cerró sesión.");
    }

    public String getNombreUsuario() {
        return nombreUsuario;
    }

    public String getCorreo() {
        return correo;
    }
}