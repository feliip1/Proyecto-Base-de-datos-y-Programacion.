package rapidoseinformaticos;

public class Carrera {

    private String nombre;
    private String fecha;
    private int vueltas;
    private String clima;
    private String estado;

    public Carrera(String nombre, String fecha,
            int vueltas, String clima, String estado) {

		 this.nombre = nombre;
		 this.fecha = fecha;
		 this.vueltas = vueltas;
		 this.clima = clima;
		 this.estado = estado;
		}
    public void programar() {
        estado = "Programada";
    }

    public void iniciar() {
        estado = "En curso";
        System.out.println("La carrera " + nombre + " ha comenzado.");
    }

    public void finalizar() {
        estado = "Finalizada";
        System.out.println("La carrera " + nombre + " ha finalizado.");
    }

    public void cancelar() {
        estado = "Cancelada";
        System.out.println("La carrera " + nombre + " ha sido cancelada.");
    }

    public String getEstado() {
    	return estado;
    
    }
    public void getCarrera() {
    	System.out.println("Obteniendo datos de la carrera");
    	System.out.println("Nombre" + nombre + "\nFecha:" + fecha + "\nVueltas:" + vueltas + "\n Clima:" + clima + "\nEstado:" + estado);

    }
}