package rapidoseinformaticos;

public class Circuito {

    private String nombre;
    private String pais;
    private double longitud;

    public Circuito(String nombre, String pais, double longitud) {
        this.nombre = nombre;
        this.pais = pais;
        this.longitud = longitud;
    }

    public String getNombre() {
        return nombre;
    }

    public String getPais() {
        return pais;
    }

    public double getLongitud() {
        return longitud;
    }
}