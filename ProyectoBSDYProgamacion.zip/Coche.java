package rapidoseinformaticos;

public class Coche {

    private String modelo;
    private int numero;

    public Coche(String modelo, int numero) {
        this.modelo = modelo;
        this.numero = numero;
    }

    public String getModelo() {
        return modelo;
    }

    public int getNumero() {
        return numero;
    }
    
}