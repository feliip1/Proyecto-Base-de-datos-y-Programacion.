package rapidoseinformaticos;

public class Temporada {

    private int anio;

    public Temporada(int anio) {
        this.anio = anio;
    }

    public int getAnio() {
        return anio;
    }
}