package rapidoseinformaticos;

public class Piloto {

    private String nombre;
    private int numero;

    public Piloto(String nombre, int numero) {
        this.nombre = nombre;
        this.numero = numero;
    }

    public void conducir() {
        System.out.println(nombre + " está conduciendo.");
    }

    public String getNombre() {
        return nombre;
    }

    public int getNumero() {
        return numero;
    }
}